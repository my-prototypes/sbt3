package br.es.ufpi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyimagesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyimagesApplication.class, args);
	}

}
